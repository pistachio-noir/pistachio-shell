# Pistachio Noir Shell

A Quickshell (QML) desktop shell for Hyprland on a single-monitor desktop PC (Arch), in the Pistachio Noir colour scheme. No code exists yet. The design is done and the plan is written; this repo is where the code gets built.

Read these first:

- `docs/plan.md`: architecture, folder layout, theme tokens, components, build phases, risks.
- `docs/audio-bluetooth.md`: PipeWire, BlueZ, brightness and OSD design, with property names checked against the Quickshell 0.3.2 docs.
- `design/*.dc.html`: one HTML board per screen. Open `design/index.html` in a browser. These are the visual source of truth for sizes, radii, spacing and colours.

## Decisions (already made, do not reopen)

- Toolkit: Quickshell 0.3.2 with QML. A from-scratch shell in C++ or Rust is a separate, later project.
- Compositor: Hyprland only. mangowm is dropped for now. Keep a thin `Compositor` singleton so UI files never import a compositor module directly.
- Single monitor. Desktop PC: no battery, no UPower, no `Power.qml`. Wired network (Ethernet), no Wi-Fi.
- Bar: floating, centred pill at the bottom, 640 x 56, radius 28, 16 px above the bottom edge. It auto-hides when a window overlaps it (exclusive zone 0, thin bottom-edge strip reveals it on hover). Leave a ~72 px bottom gap in the Hyprland config so tiled windows stay clear.
- Bar content: workspaces and window title, clock, date and notification indicator, status chip with Ethernet, Bluetooth and volume.
- Other parts: quick settings (Ethernet, Bluetooth, Do not disturb, Night light tiles; volume, brightness and night light warmth sliders; uptime and power button), notification popups and centre, OSD, power menu, lock screen, app launcher.
- Launcher modes: Apps, Windows, Workspaces, System (volume, brightness, outputs), Bluetooth. It may replace Vicinae; decide after build phase 6.
- Motion: smooth fades and slides, one easing curve (ease-out), 120 ms for hover and about 200 ms for fades and slides.

## Style rules

- Colours come only from `Theme.qml`. No hard-coded hex values elsewhere.
- Palette: bg #15170F, bgAlt #1D2016, overlay #2A2F1F, overlay2 #39412A, muted #626F51, subtext #A3B08F, text #E5E9D8, textBright #F6F8EF, pistachio #9FD88A (active state only), terracotta #DB8267, gold #E0B15E, sageBlue #7DA3B3, teal #7FC9A8, lavender #AC8ED0, clay #D9975A.
- `muted` is only about 3.4:1 on bg, so never use it for small text; use `subtext`.
- Pistachio marks what is active: current workspace, toggles that are on, slider fills, the cursor, and the selected-row chip (pistachio background with bg-coloured text). No accent borders and no large pistachio fills.
- Fonts: Manrope (weights 500 to 800) for the UI, JetBrains Mono for code-like text. Numbers use tabular figures.
- Shapes are soft: radius 28 for panels, 20 for chips and tiles, fully round for icon buttons.

## Working rules for Claude Code

1. Verify any Quickshell module, type or property against https://quickshell.org/docs/v0.3.2/ before using it. Names marked with `*` in `docs/plan.md` (`SystemClock`, `IpcHandler`, `DesktopEntries`) came from memory and are unchecked. `docs/audio-bluetooth.md` lists the other open questions (PIN prompts, per-app volume filter, brightness IPC).
2. Follow the build phases in `docs/plan.md` in order, one at a time. After each, run the shell and check it against the matching board in `design/`.
3. Quickshell reloads on save. Run it with `qs -c pistachio` and read its log for QML errors before saying something works.
4. Keep services (`Audio`, `Bluetooth`, `Network`, `Brightness`, `NightLight`, `Notifs`) and the `Compositor` adapter as the only places that touch system data. UI files only read from them.
5. Only one notification daemon can run at a time. Stop any existing one before testing notifications.
6. Keep the existing screen locker bound as a fallback until the shell's lock screen is proven. Keep a TTY available when testing the lock.
7. The mockup sample content (window titles, device names, "1 Gbps", "3 h 12 min", "Until 07:00") is made up. Wire real data; do not copy the strings.
8. Night light probably uses `hyprsunset`, which is unchecked. Confirm its CLI or IPC before relying on it.

## Open questions for the owner

- Which Vicinae features are used besides launching apps (clipboard history, calculator, snippets)?
- Is a ~72 px Hyprland bottom gap acceptable?
