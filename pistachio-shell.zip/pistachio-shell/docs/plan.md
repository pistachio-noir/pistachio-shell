# Pistachio Noir Shell: Quickshell plan

Oct 25, 2026 · @sxnvte

## Decisions so far

We are building a Quickshell (QML) shell for Hyprland in Pistachio Noir. The visual design is done on the [design boards](../design/); this doc plans the code. Nothing is built yet.

- **Toolkit:** Quickshell 0.3.2 with QML. A from-scratch shell in C++ or Rust is a separate, later project. mangowm is dropped for now in favour of tighter Hyprland integration.
- **Look:** a compact pill, centred and floating at the bottom, soft and rounded. Only Pistachio Noir colours, with pistachio reserved for what is active.
- **Bar:** workspaces/tags and window title; clock, date and notification indicator; tray with Ethernet, Bluetooth and volume (a desktop PC, so no battery).
- **Other parts:** quick settings, notification popups and centre, OSD, power menu, lock screen, and an app launcher with modes for apps, windows, workspaces and system controls.
- **Behaviour:** the bar auto-hides when a window overlaps it. Motion is smooth fades and slides. Single monitor only.
- **Launcher vs Vicinae:** we build ours; whether it fully replaces Vicinae is decided after step 6 of the build phases.

## Architecture

The shell UI reads from exactly two places: the `Compositor` adapter and the system services. Everything compositor-specific stays behind the adapter.

```
Hyprland
   |
Compositor.qml  (thin adapter, Hyprland backend only)
   |                                   System services
   +--> Shell UI  <-------------------  Audio, Bluetooth, Network,
        (bar, panels, popups,           Brightness, NightLight, Notifs
         launcher, lock)
```

The adapter is thin today, with a Hyprland backend only. It exists so another compositor can be added later without touching the UI.

## Project layout

One config folder, split by what each file is for: a theme singleton, services that wrap data sources, and UI folders that only read from them. Confirm the folder name and how singletons are registered in the 0.3.2 docs at step 1.

```
~/.config/quickshell/pistachio/
├─ shell.qml            entry point, loads the parts below
├─ Theme.qml            singleton: colours, radii, sizes, durations
├─ services/
│  ├─ Compositor.qml    singleton: the adapter (next section)
│  ├─ HyprlandBackend.qml
│  ├─ (other compositors, later)
│  ├─ Audio.qml  Bluetooth.qml  Network.qml  Brightness.qml  NightLight.qml  Notifs.qml
├─ bar/                 Bar, Workspaces, WindowTitle, ClockChip, StatusChip
├─ panels/              QuickSettings, NotificationCentre, PowerMenu
├─ popups/              Toasts, Osd
├─ launcher/            Launcher, ModeTabs, providers/ (Apps, Windows, Workspaces, System, Bluetooth)
├─ lock/                Lock
└─ components/          Chip, IconButton, Slider, Switch, Pill
```

Rule: files under `bar/`, `panels/`, `popups/`, `launcher/` and `lock/` never import a compositor module directly. They use `Compositor` and the services.

## Compositor adapter

The adapter is one thin singleton, `Compositor`, with a Hyprland backend only. The bar, launcher and auto-hide code use only its API, so adding another compositor later touches one file.

| Adapter API | Used by | Hyprland source |
| --- | --- | --- |
| `workspaces` (id, name, occupied, urgent, active) | bar, launcher | `Quickshell.Hyprland` module |
| `focusedWindow` (title, appId) | bar | `Quickshell.Hyprland` module |
| `windows` (title, appId, workspace, urgent) | launcher Windows mode | `Quickshell.Hyprland` module and `ToplevelManager` from `Quickshell.Wayland` |
| `windowBounds` | auto-hide | Hyprland client position and size; confirm the exact call at step 1 |
| `goto`, `moveWindow`, `focus`, `close` | launcher | Hyprland dispatchers |

With Hyprland only, there is no protocol to parse: the built-in module and Hyprland's dispatchers should cover the whole table. Confirm that at step 1.

**Auto-hide rule.** The bar hides when any window on the current workspace intersects the bar's rectangle plus a small margin. A thin always-present strip at the bottom edge shows it again on hover. For this to work the bar must not reserve screen space (exclusive zone 0), and the compositor's bottom gap should leave room for the bar so normal tiles never overlap it. Floating, maximised and fullscreen windows will.

## Theme and motion

`Theme.qml` is the only place with colours, sizes and durations; every other file reads from it. Values come from the design canvas.

| Token | Value | Role |
| --- | --- | --- |
| `bg` | #15170F | window and editor background |
| `bgAlt` | #1D2016 | bar, panels, popups, launcher |
| `overlay` | #2A2F1F | chips, tiles, hover |
| `overlay2` | #39412A | selected row, pressed chip, outlines |
| `muted` | #626F51 | inactive dots, disabled (not for small text) |
| `subtext` | #A3B08F | secondary text |
| `text` / `textBright` | #E5E9D8 / #F6F8EF | body / emphasis |
| `pistachio` | #9FD88A | active only: current workspace, toggles on, slider fill, cursor |
| `terracotta`, `gold`, `sageBlue`, `teal`, `lavender`, `clay` | #DB8267, #E0B15E, #7DA3B3, #7FC9A8, #AC8ED0, #D9975A | status and small icons |

Sizes: bar 640 × 56, radius 28, 16 px above the bottom edge; chips 40 px high with radius 20; panels 380–400 px wide with radius 28; tiles radius 20. The wallpaper tone #0D0F09 in the mockups is a placeholder, not a theme token.

Motion rules, so everything feels the same:

- One easing curve (ease-out) and one duration scale: 120 ms for hover, about 200 ms for fades and slides.
- Popups fade in and rise about 12 px. Panels grow from the chip that opened them.
- The active workspace capsule animates its width between 8 and 26 px as focus moves.
- The bar hides by sliding down its own height plus margin while fading, and returns the same way.
- Fonts: Manrope for the UI, JetBrains Mono for code-like text. Check both are installed; they are mockup choices.

## Components

Each piece, where its data comes from, and what is not built in. Module names marked \* come from my memory of Quickshell, not from the docs I read; confirm them at step 1. The others are in the [0.3.2 module list](https://quickshell.org/docs/v0.3.2/types).

| Component | Data source | Notes |
| --- | --- | --- |
| Bar window | `PanelWindow`, layer-shell via `Quickshell.Wayland` | anchored bottom, centred, exclusive zone 0 for auto-hide |
| Workspaces, window title | `Compositor` adapter | capsule animates; urgent dot in terracotta |
| Clock chip | `SystemClock`\* | opens the notification centre |
| Status chip | `Quickshell.Services.Pipewire`, `Quickshell.Bluetooth`, `Quickshell.Networking`, `Quickshell.Services.SystemTray` | opens quick settings |
| Quick settings | the same services | brightness has no built-in module: run `brightnessctl` through `Quickshell.Io`. Night light needs an external tool, probably hyprsunset on Hyprland (unchecked) |
| Notifications | `Quickshell.Services.Notifications` | we become the notification daemon, so any other daemon must not run. Popups, history list and do-not-disturb live here |
| OSD | Pipewire, plus a command from the volume and brightness keybinds | `IpcHandler`\* lets a keybind call the shell; brightness changes are not observable otherwise |
| Power menu | `Process` from `Quickshell.Io` | logout, suspend, reboot and shutdown commands; logout uses Hyprland's exit dispatcher |
| Lock screen | `WlSessionLock`, `Quickshell.Services.Pam` | Hyprland supports the session-lock protocol; confirm at step 7. Keep an existing locker as fallback until the shell's lock is proven |
| Launcher | `DesktopEntries`\*, `Compositor`, the services | providers per mode: Apps, Windows, Workspaces, System, Bluetooth. Fuzzy match with highlighted letters |

## Audio, Bluetooth and brightness

Audio and Bluetooth each get one service singleton built on Quickshell's own PipeWire and BlueZ modules, with no command-line parsing. Brightness uses `brightnessctl`, and night light uses an external tool. The full design, with the property names checked against the 0.3.2 docs, is in the [Audio and Bluetooth doc](audio-bluetooth.md).

This is a desktop PC, so there is no battery and no `Power.qml` service: the status chip shows Ethernet, Bluetooth and volume only. The network tile means a wired link, with no Wi-Fi scanning or password prompts.

## Build phases

Eight steps, each ending in something you can see working. Everything targets Hyprland, whose integration is built into Quickshell.

| # | Phase | Done when |
| --- | --- | --- |
| 1 | Skeleton: `Theme.qml` and an empty pill; confirm folder name, singletons and module names | the pill floats 16 px above the bottom, centred, in the right colours, and reloads on save |
| 2 | Bar content: workspaces, window title, clock chip, status chip | it matches the Bar artboard and switching workspace moves the capsule |
| 3 | `Compositor` adapter: window list, window bounds and actions | the bar and the launcher's window data read from `Compositor`, never from the Hyprland module directly |
| 4 | Quick settings: audio, Bluetooth, Ethernet, brightness, night light | every slider and toggle changes the real system state |
| 5 | Notifications: popups, centre, do-not-disturb | `notify-send` shows a toast, the centre lists it, do-not-disturb silences new ones |
| 6 | Launcher: apps first, then Windows, Workspaces and System modes | you can launch apps, switch windows and workspaces and set volume from it; decide here about Vicinae |
| 7 | OSD, power menu, lock screen | lock and unlock work with your password, tested with a fallback way back in (a TTY) |
| 8 | Auto-hide and motion polish | the bar hides when a window overlaps and returns on bottom-edge hover, all with one easing curve |

## Risks and open questions

Dropping mangowm removes the biggest integration risk. What remains is mostly API details not yet checked against the 0.3.2 docs.

- **Auto-hide needs window geometry** from Hyprland. Confirm the exact call at step 1.
- **Lock screen.** Keep your current locker bound as a fallback until the shell's lock is proven.
- **One notification daemon at a time.** Stop any existing daemon before step 5.
- **Module names and APIs** marked with \* in Components come from memory and may differ in 0.3.2.
- **Real app icons.** The mockups use placeholder glyphs; the launcher must resolve icons from the system icon theme.

Questions for you:

- [ ] Which Vicinae features do you use besides app launching (clipboard history, calculator, snippets)?
- [ ] Are you happy to set a Hyprland bottom gap of about 72 px so tiled windows stay clear of the bar?

## Later: the from-scratch version

A full rewrite in C++ or Rust is out of scope now. To keep that door open, keep three things independent of QML: the design tokens (plain values in `Theme.qml`), the adapter's API table above, and the list of components and their data sources. A later Rust shell could reuse all three, and mangowm can come back as a second backend behind the adapter. A small Rust helper for the launcher's app index and fuzzy search is the natural first Rust piece, added only if doing that in QML feels slow or awkward.
