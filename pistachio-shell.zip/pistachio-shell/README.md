# Pistachio Noir Shell: handoff bundle

Everything needed to start building the shell with Claude Code on your own machine.

```
pistachio-shell/
├─ CLAUDE.md             decisions, style rules and working rules; Claude Code reads it automatically
├─ README.md             this file
├─ docs/
│  ├─ plan.md            architecture, layout, tokens, build phases, risks
│  └─ audio-bluetooth.md PipeWire, BlueZ, brightness, OSD
└─ design/
   ├─ index.html         open this to see every board
   └─ *.dc.html          the 15 boards (desktop, bar, panels, popups, lock, launcher modes)
```

## Moving over

1. **Unpack it where you keep projects**, and make it a git repo:

   ```sh
   unzip pistachio-shell.zip -d ~/projects
   cd ~/projects/pistachio-shell
   git init && git add -A && git commit -m "Design and plan"
   ```

2. **Install the tools** (package names are from memory; check them with `pacman -Ss` first):

   ```sh
   sudo pacman -S hyprland pipewire wireplumber pipewire-pulse bluez bluez-utils brightnessctl
   sudo systemctl enable --now bluetooth.service
   ```

   Quickshell may be in the official repos; if not, use the AUR package (`quickshell`, or `quickshell-git` for the latest). Night light probably needs `hyprsunset`, which is unchecked. Also install the fonts, `ttf-manrope` and `ttf-jetbrains-mono`, if your repos have them.

3. **Install Claude Code** by following the install page at https://docs.claude.com/en/docs/claude-code, then start it inside the repo:

   ```sh
   cd ~/projects/pistachio-shell
   claude
   ```

   It reads `CLAUDE.md` on its own, so it already knows the decisions and rules.

4. **Give it a first task.** Something like:

   > Read docs/plan.md and docs/audio-bluetooth.md and open design/index.html. Do build phase 1 only: create `src/` with `shell.qml` and `Theme.qml`, and an empty floating pill. Verify every Quickshell type against the 0.3.2 docs first. Tell me how to run it.

   Then continue phase by phase. After each one, compare the running shell with the matching board in `design/`.

5. **Run the shell from the repo.** Quickshell looks for configs in `~/.config/quickshell/<name>/`, so link the repo's `src/` folder there:

   ```sh
   ln -s ~/projects/pistachio-shell/src ~/.config/quickshell/pistachio
   qs -c pistachio
   ```

   It reloads on save, so edits show up immediately. Test inside a Hyprland session (pick it at the login screen), because the bar needs layer-shell and Hyprland's window data.

## Keeping things in sync

- The design canvas and the two docs on claude.ai stay as they are. This folder is a snapshot of them from 2026-10-25.
- If the design changes later, change it in that chat and re-export, or edit the HTML boards here directly.
- If the plan changes while building, let Claude Code update `docs/plan.md` and `CLAUDE.md` in the repo; the repo copy is the working one from now on.
